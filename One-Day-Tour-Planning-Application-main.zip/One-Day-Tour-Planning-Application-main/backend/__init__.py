"""Backend package for Tour Planner application."""
# Empty init file - we don't need imports here